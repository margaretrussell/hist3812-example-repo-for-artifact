# bibliography

Benjamin, W. (1968). The Work of Art in the Age of Mechanical Reproduction. In: *Illuminations*. New York: Schocken Books, pp. 217-251.

Latour, Bruno, and A. Lowe (2011). The Migration of the Aura - or How to Explore the Original Through Its Facsimiles. In: T. Bartscherer and R. Coover, ed., *Switching Codes. Thinking Through Digital Technology in the Humanities and the Arts*, University of Chicago Press, pp. 275-297.

Stünkel, E. (2013). *Precaution*. {Youtube video}. New York City: The Metropolitan Museum of Art.

Regard3D. (No year provided). *Tutorial*. {online}. Available at: http://www.regard3d.org/index.php/documentation/tutorial {Accessed 22 Jan. 2018}
