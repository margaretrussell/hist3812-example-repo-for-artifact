# Object Files: Sketchfab

Link to the model on Sketchfab in the case that the files do not work: https://sketchfab.com/models/d4c37708d2ca42d588e1fea1fab65e9d
